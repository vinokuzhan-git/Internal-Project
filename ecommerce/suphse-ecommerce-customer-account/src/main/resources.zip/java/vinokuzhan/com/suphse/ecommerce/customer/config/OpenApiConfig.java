package vinokuzhan.com.suphse.ecommerce.customer.config;
import org.springdoc.core.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public GroupedOpenApi groupedOpenApi() {
        return GroupedOpenApi.builder()
                .group("api")  // Specify a group name
                .pathsToMatch("/ecommerce/**")  // Specify paths to include
                .packagesToScan("vinokuzhan.com.suphse.ecommerce.customer.controller")  // Specify package to scan for controllers
                .build();
    }
}
